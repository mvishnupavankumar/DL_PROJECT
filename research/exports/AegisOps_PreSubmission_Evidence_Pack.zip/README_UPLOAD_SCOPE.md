# AegisOps Pre-Submission Evidence Pack

**Archive**: `AegisOps_PreSubmission_Evidence_Pack.zip`  
**Date**: October 14, 2026  
**Purpose**: Self-contained, upload-ready evidence pack packaged for ChatGPT independent peer review.  
**Source Repository**: `C:\DL_PROJECT` (Branch: `publish/research-without-external-dataset`, HEAD: `a32713c30a8ddca1425d44b1afbaf6d55a64c276`)  
**Standard**: Strict Research Integrity & Non-Destructive Packaging  

---

## 1. What This Evidence Pack Contains

This pack packages the exact, latest local working-tree files necessary to verify every quantitative claim, table, figure, and architectural conclusion in the AegisOps research paper:

1. **Six Canonical Raw CSV Files** (`files/research/raw/`):
   - `detection_predictions.csv`: 320 evaluation windows across 6 incident classes and steady state.
   - `detection_metrics.csv` & `detection_by_scenario.csv`: Performance metrics and scenario breakdown.
   - `diagnosis_predictions.csv`: 42 evaluation records across 7 diagnostic configurations.
   - `diagnosis_metrics.csv`: ITT, completed-case accuracies, and execution latencies.
   - `safety_test_results.csv`: 16 execution boundary evaluations.
   - `safety_metrics.csv`: Attack containment, check latency, and audit verification metrics.

2. **Manuscript & Cross-Verification Documents** (`files/research/paper/`):
   - `AEGISOPS_RESEARCH_PAPER.md`: Complete research manuscript.
   - `CANONICAL_METRIC_RECONCILIATION.md`: Authoritative canonical metric reconciliation matrix.
   - `FIGURE_AND_TABLE_INDEX.md`: Cross-verification index for all tables and figures.
   - `MANUSCRIPT_CLAIM_EVIDENCE_MATRIX.md`: End-to-end claim traceability.
   - `figures/`: Confusion matrices PNG, comparison PNG, and Mermaid architecture diagrams.

3. **Audits, Governance & Checklists** (`files/research/audits/`, `files/research/`):
   - `FINAL_REPOSITORY_INTEGRITY_RECONCILIATION.md`: Full manifest recomputation and reconciliation.
   - `AEGISOPS_MASTER_RESEARCH_HANDOFF.md`: Master handoff and scientific status matrix.
   - `UPDATED_SEVEN_PHASE_CHECKLIST.md`: Categorical governance checklist and QC-1 to QC-8 criteria.
   - `BOUNDED_CLAIMS_DECISION.md` & `EXPERIMENT_D_FINAL_SUPERVISOR_DECISION.md`: Ratified Path 3 policy.
   - `MANIFEST_SHA256.json`: Unmodified historical baseline manifest covering 22 artifacts.

4. **Verification Source Code** (`files/`):
   - `approval.py`: Transactional dual-authorization and atomic SQLite approval barrier.
   - `dl/anomaly_detector.py`: Multivariate LSTM Autoencoder and dual-gate detector implementation.
   - `models/lstm_autoencoder.json`: Hyperparameter contract and threshold metadata (\(\tau = 0.709399\)).
   - `research/experiments/`: Experiment A, B, C runners, safety harness, and diagnosis auditor.

5. **Inventory & Verification Metadata** (`inventory/`):
   - `SHA256_INVENTORY.csv`: Machine-readable inventory of all 55 included files with SHA-256 hashes.
   - `LOCAL_REPOSITORY_STATE.txt`: Detailed Git identity, branch, HEAD, and working-tree status.
   - `MISSING_FILES_AND_WARNINGS.md`: Explicit documentation of missing PDF, exclusions, and manifest diffs.

---

## 2. Directory Structure Inside the ZIP

```text
AegisOps_PreSubmission_Evidence_Pack.zip
├── README_UPLOAD_SCOPE.md
├── files/
│   ├── approval.py
│   ├── dl/
│   │   └── anomaly_detector.py
│   ├── models/
│   │   └── lstm_autoencoder.json
│   └── research/
│       ├── MANIFEST_SHA256.json
│       ├── SAFETY_EVALUATION.md
│       ├── ... (evidence reports)
│       ├── raw/
│       │   ├── detection_predictions.csv
│       │   ├── detection_metrics.csv
│       │   ├── diagnosis_predictions.csv
│       │   ├── diagnosis_metrics.csv
│       │   ├── safety_test_results.csv
│       │   └── safety_metrics.csv
│       ├── paper/
│       │   ├── AEGISOPS_RESEARCH_PAPER.md
│       │   ├── CANONICAL_METRIC_RECONCILIATION.md
│       │   └── figures/
│       ├── audits/
│       │   ├── FINAL_REPOSITORY_INTEGRITY_RECONCILIATION.md
│       │   └── ...
│       └── experiments/
│           ├── run_experiment_a.py
│           └── ...
└── inventory/
    ├── SHA256_INVENTORY.csv
    ├── LOCAL_REPOSITORY_STATE.txt
    └── MISSING_FILES_AND_WARNINGS.md
```

---

## 3. Disclaimers & Packaging Scope

- **Evidence Copies Only**: This archive packages exact copies of files from the local research repository for independent evaluation.
- **No Independent Scientific Validation**: Packaging and verifying hash concordance does not constitute an independent validation of experimental results or certify submission readiness.
- **Historical vs. Audited Records**: As documented in `MISSING_FILES_AND_WARNINGS.md`, the detection predictions match the historical manifest bit-for-bit, while diagnosis and safety CSVs represent audited classifications and recomputed metrics.
