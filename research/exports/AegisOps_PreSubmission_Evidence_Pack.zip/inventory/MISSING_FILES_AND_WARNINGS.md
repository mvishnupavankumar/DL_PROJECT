# AegisOps Pre-Submission Evidence Pack: Missing Files, Exclusions & Integrity Warnings

**Document Identifier**: `AEGISOPS-PRE-SUBMISSION-EVIDENCE-WARNINGS`  
**Date**: October 14, 2026  
**Auditor**: Senior ML Research Supervisor, Statistical Auditor & Reproducibility Reviewer  

---

## 1. Missing Files Audit

- **Rendered Research Paper PDF**: **NOT PRESENT IN REPOSITORY**
  - Forensic inspection across the entire `C:\DL_PROJECT` directory confirmed that no pre-compiled `AEGISOPS_RESEARCH_PAPER.pdf` exists.
  - Per instructions, **no synthetic or placeholder PDF was fabricated**. Camera-ready PDF rendering remains deferred pending visual layout and typography proofing.
  - The full, authoritative markdown manuscript is provided at `files/research/paper/AEGISOPS_RESEARCH_PAPER.md` with accompanying figures in `files/research/paper/figures/`.
- **Canonical Raw CSV Files**: **ALL 6 PRESENT AND VERIFIED**
  - All six canonical CSV files (`detection_predictions.csv`, `detection_metrics.csv`, `diagnosis_predictions.csv`, `diagnosis_metrics.csv`, `safety_test_results.csv`, `safety_metrics.csv`) are included directly from `research/raw/`.
- **Evidence and Source Code Files**: **ALL 55 REQUESTED FILES PRESENT AND VERIFIED**
  - Zero requested evidence documents or source modules are missing.

---

## 2. Intentional Manifest Discrepancies (Historical Baseline vs. Audited Evidence)

The historical manifest `files/research/MANIFEST_SHA256.json` (generated 2026-10-12T08:44:36Z) covers 22 artifacts. Read-only verification reveals that **17 artifacts match bit-for-bit**, while **5 artifacts differ intentionally**:
1. `research/SAFETY_EVALUATION.md`: Table layout updated to disaggregate 11 adversarial attacks from 5 precondition and verification probes.
2. `research/raw/diagnosis_predictions.csv`: Rows 25 & 39 reclassified from `INCORRECT` to `UNASSESSABLE` due to omitted API calls.
3. `research/raw/diagnosis_metrics.csv`: Completed-case strict accuracy updated to 80.00% and valid completed latencies isolated.
4. `research/raw/safety_test_results.csv`: Test cases `TC-FAIL-01/02` and `TC-VERIF-01` categorized as precondition checks and recovery verification probes.
5. `research/raw/safety_metrics.csv`: Adversarial attack denominator corrected from 14 to 11 (100% containment, 95% Wilson CI [0.7412, 1.0000]); attack check latency isolated (11.32 ms).

These changes represent deliberate scientific reconciliation, fully documented in `files/research/audits/FINAL_REPOSITORY_INTEGRITY_RECONCILIATION.md` and `files/research/paper/CANONICAL_METRIC_RECONCILIATION.md`. The manifest itself was **not modified or regenerated**.

---

## 3. Strict Exclusions

The following assets were strictly excluded from this evidence pack per protocol:
1. **Model Checkpoint Binaries (`.pt`)**: `models/lstm_autoencoder.pt` (19,797 bytes) was excluded to maintain a lean, text-first evidence package suitable for LLM review. The model architecture contract and threshold (\(\tau = 0.709399\)) are fully documented in `files/models/lstm_autoencoder.json` and `files/dl/anomaly_detector.py`.
2. **External Dataset Archives**: `data/external/anomod/` (38,349 files, >200 MB) was excluded under the Supervisor-Ratified Path 3 Bounded-Claims Policy (production Experiment D is formally unexecuted and deferred).
3. **Runtime SQLite Databases**: `data/*.sqlite3` were excluded; schemas and audit trails are documented in `files/research/audits/DATABASE_AUDIT.md`.
4. **Python Virtual Environment & Caches**: `.venv/`, `__pycache__/`, `.pytest_cache/` excluded.
5. **Secrets & Credentials**: `.env` excluded. An automated regex scan confirmed **zero API keys, tokens, or private credentials** exist in the packaged evidence files.
