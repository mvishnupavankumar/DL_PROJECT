# AegisOps Review Bundle 1: Manuscript and Empirical Evidence

This bundle contains the complete research paper, figure assets, evidence matrices,
canonical raw experiment CSV records, derived results, statistical analysis scripts,
and the frozen SHA-256 baseline manifest.

## Key Documents:
- `research/paper/AEGISOPS_RESEARCH_PAPER.md`: Full research manuscript
- `research/paper/CANONICAL_METRIC_RECONCILIATION.md`: Authoritative canonical metric reconciliation
- `research/paper/FIGURE_AND_TABLE_INDEX.md`: Cross-verification index for all tables and figures
- `research/paper/MANUSCRIPT_CLAIM_EVIDENCE_MATRIX.md`: End-to-end claim traceability
- `research/raw/`: Canonical primary experiment CSV records (detection, diagnosis, safety)
- `research/results/`: Derived result CSVs, statistical test calculator, and markdown outputs
- `research/MANIFEST_SHA256.json`: Baseline artifact hash manifest covering 22 artifacts
