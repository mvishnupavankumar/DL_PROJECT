# AegisOps Review Bundle 2: Source Code, Tests, and Model Checkpoints

This bundle contains the complete application source code, automated test suites,
experiment runners, utility scripts, frozen PyTorch model checkpoint and metadata,
and execution logs substantiating all reported test passes.

## Key Components:
- Root modules: `agents.py`, `approval.py`, `live_monitoring.py`, `config.py`, `simulator.py`
- Subsystem modules: `collectors/`, `demo_service/`, `dl/`, `storage/`
- Automated tests: `test_*.py` (11 test suites covering detection, approval, agents, harness)
- Experiment runners: `research/experiments/` (Experiment A, B, C runners and diagnosis auditor)
- Utility scripts: `research/scripts/` (temporal audit, AnoMod ingestion preflight)
- Model checkpoint: `models/lstm_autoencoder.pt` (SHA-256 `1cf44e6e...`, 19,797 bytes)
- Model metadata: `models/lstm_autoencoder.json` (threshold $\tau = 0.709399$)
- Verified test logs: `test_logs/` (substantiating 107-test and 18-test clean exit codes)
