# AegisOps — Live Telemetry Monitoring and Multi-Agent Incident Response

A local research prototype that combines a **PyTorch LSTM Autoencoder** with specialized agents for telemetry investigation, diagnosis, constrained remediation, and recovery verification.

## Live Monitoring only

The dashboard opens directly into Live Monitoring. Collection can also run independently of the dashboard via `python -m collectors.worker`. The synthetic Incident Demo workspace and its workspace selector have been removed from the application UI.

Live Monitoring:
- Collects actual host CPU, memory, and disk readings through `psutil`.
- Times HTTP requests against a configurable HTTP(S) service probe and records status/error-rate metrics. Remote targets require HTTPS; optional bearer-token authentication is supported.
- Stores timestamped observations and audit events in SQLite.
- Exports collected telemetry as CSV.
- Trains a separate LSTM checkpoint from eligible healthy live observations. The dashboard does not use the legacy synthetic-demo checkpoint for live scoring.
- Combines the LSTM score with explicit guardrails for obvious live service failures.
- Sends current metrics, service logs, and detector evidence into the investigation/diagnosis workflow.
- Supports controlled latency/HTTP 500 fault injection against the local test service.
- Allows only one live remediation action: reset the local test service's fault switch after explicit human approval, then verify actual HTTP health/probe results.

> **Safety and scope:** this is a local research prototype, not a production remediation platform. The local test service's admin endpoint is unauthenticated for local testing; keep it bound to `127.0.0.1` and never expose port 8765 to a network.

## Project structure

```text
AegisOps/
├── app.py
├── live_monitoring.py
├── agents.py
├── demo_service/
│   └── main.py
├── collectors/
│   └── system_metrics.py
├── storage/
│   └── telemetry_store.py
├── dl/
│   ├── anomaly_detector.py
│   ├── live_training.py
│   ├── train_from_csv.py
│   └── evaluate_detector.py
├── models/
├── data/
├── test_*.py
├── run_all.ps1
├── run_all.bat
├── START_HERE.md
├── LIVE_DATA_GUIDE.md
└── RESEARCH_PLAN.md
```

Runtime files are generated locally:
- `data/aegisops_live.sqlite3` — telemetry and audit history.
- `models/live_lstm_autoencoder.pt` — model trained from healthy live telemetry.
- `models/live_lstm_autoencoder.json` — training and calibration metadata.

## Setup on Windows

Run in PowerShell inside the extracted `AegisOps` folder:

```powershell
python -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

## Run live monitoring

Recommended:

```powershell
.\\run_all.ps1
```

Or use two terminals.

Terminal 1 — local test service:

```powershell
.\\.venv\\Scripts\\Activate.ps1
python -m uvicorn demo_service.main:app --host 127.0.0.1 --port 8765
```

Terminal 2 — dashboard:

```powershell
.\\.venv\\Scripts\\Activate.ps1
python -m streamlit run app.py
```

The dashboard opens directly into Live Monitoring. Collection can also run independently of the dashboard via `python -m collectors.worker`.

## Live-data workflow

1. Keep the local test service in `normal` mode.
2. Enable five-second collection.
3. Collect at least 180 eligible healthy samples; preferably collect 240 or more before training. Do not inject faults during baseline collection.
4. Train through **Train / retrain LSTM from healthy live telemetry**, or use `dl.train_from_csv` with an exported healthy-baseline CSV.
5. Inject a local latency or HTTP 500 fault and wait for telemetry to update.
6. Run the agents over live evidence.
7. Approve the allowed local remediation and verify recovery.
8. Export telemetry and inspect the SQLite audit trail.

Detailed instructions are in [START_HERE.md](START_HERE.md), [LIVE_DATA_GUIDE.md](LIVE_DATA_GUIDE.md), [SECURITY.md](SECURITY.md), and [OPERATIONS.md](OPERATIONS.md).

## Optional Groq LLM agents

Without `GROQ_API_KEY`, agents use deterministic offline behavior. For LLM calls, set a valid key and a model available to your Groq account in `.env`. Never commit or share `.env`.

## Tests and research integrity

Run:

```powershell
python -m pytest -q
```

The synthetic detector evaluator and synthetic fixtures are retained only as legacy regression/reproducibility utilities; they are not a dashboard mode and their metrics are not live-data accuracy claims. Real performance claims require labeled, held-out live or controlled-fault data.


## Recovery approval hardening (local evaluation)

The local-only test-fault reset now uses an expiring, one-time SQLite approval ticket bound to the action, exact target URL, and incident ID. The operator must type `APPROVE clear_demo_service_fault` before approval can be recorded. See `WINDOWS_DEPLOYMENT.md` and `SECURITY.md`. Approval labels are not authenticated identities; do not expose this UI as a production control plane.
